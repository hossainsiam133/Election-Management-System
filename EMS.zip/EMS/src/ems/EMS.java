package ems;

import javax.swing.JOptionPane;
public class EMS {

    
    public static void main(String[] args) {
        new Splash().setVisible(true);
    }
}
